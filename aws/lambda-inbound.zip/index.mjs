import { SESClient } from "@aws-sdk/client-ses";
import { S3Client, GetObjectCommand } from "@aws-sdk/client-s3";
// We use mailparser (simpleParser) to easily extract fields from the raw email stream Let's assume you add it as a Layer or package.json
import { simpleParser } from "mailparser";

const s3 = new S3Client({ region: "eu-west-3" });

// Config using Environment Variables
const config = {
  // Use the ENV variable, appending the URL path to the Edge Function
  supabaseEdgeFunctionUrl: `${process.env["SUPABASE_URL"]}/functions/v1/process-inbound-email`,
  supabaseAnonKey: process.env["SUPABASE_ANON_KEY"],
};

export const handler = async (event) => {
  console.log("Received SES event:", JSON.stringify(event, null, 2));

  const record = event.Records[0];
  const sesNotification = record.ses;
  const messageId = sesNotification.mail.messageId;
  const receipt = sesNotification.receipt;

  console.log("Message ID:", messageId);
  console.log("Recipients:", receipt.recipients);

  const bucket = "simplifica-inbound-emails";
  const key = `incoming/${messageId}`;

  console.log(`Fetching email from S3: ${bucket}/${key}`);

  try {
    // 1. Get the raw email from S3
    const s3Response = await s3.send(
      new GetObjectCommand({
        Bucket: bucket,
        Key: key,
      }),
    );

    // 2. Parse the email using mailparser
    // We pass the readable stream directly to simpleParser
    const parsedEmail = await simpleParser(s3Response.Body);

    // Extract required fields for the Supabase Edge Function
    const from = parsedEmail.from?.value[0]?.address || parsedEmail.from?.text;
    const fromName = parsedEmail.from?.value[0]?.name;
    const subject = parsedEmail.subject || "Sin Asunto";
    const textBody = parsedEmail.text || "";
    const htmlBody = parsedEmail.html || "";
    const inReplyTo = parsedEmail.inReplyTo;

    // The intended recipient (our CRM user account)
    // receipt.recipients is an array of emails that triggered this rule
    // We can loop through them or just take the first one if we assume 1:1 delivery
    for (const recipient of receipt.recipients) {
      console.log(`Forwarding extracted email for ${recipient} to Supabase...`);

      const payload = {
        to: recipient,
        from: { name: fromName || "", email: from },
        subject: subject,
        body: textBody,
        html_body: htmlBody,
        messageId: messageId,
        inReplyTo: inReplyTo,
      };

      // 3. Send HTTP POST to Supabase Edge Function
      const response = await fetch(config.supabaseEdgeFunctionUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${config.supabaseAnonKey}`, // Typically Anon key for Edge Functions
          "x-inbound-secret":
            process.env["INBOUND_WEBHOOK_SECRET"] ||
            "XyZ_Simplifica_Inbound_2026", // Pass the secret variable
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error(
          `Supabase Edge Function failed with status ${response.status}:`,
          errorText,
        );
        throw new Error(`Failed to send to Supabase: ${response.status}`);
      }

      const responseData = await response.json();
      console.log(`Successfully sent to Supabase. Response:`, responseData);
    }

    return {
      statusCode: 200,
      body: JSON.stringify({
        message: "Email parsed and forwarded to Supabase successfully",
      }),
    };
  } catch (error) {
    console.error("Error details:", error);
    throw error;
  }
};
